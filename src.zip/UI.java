import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class UI {

    private JFrame frame;
    private JTextField lengthField;
    private JLabel resultLabel;
    private PasswordGenerator generator;



    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    UI window = new UI();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public UI() {
        initialize();
        generator = new PasswordGenerator();
    }
    private void savePasswordToFile(String password) {
        String directoryPath = "C:\\PasswordSaver";
        String filePath = directoryPath + "\\Password.txt";

        try {
            File dir = new File(directoryPath);
            if (!dir.exists() && !dir.mkdirs()) {
                JOptionPane.showMessageDialog(frame, "无法创建文件夹，请检查权限。", "错误", JOptionPane.ERROR_MESSAGE);
                return;
            }

            File file = new File(filePath);
            try (FileWriter writer = new FileWriter(file, true)) {
                writer.write(password);
                writer.write("\n");
            }
            hideFolder(directoryPath);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(frame, "保存密码时发生错误：" + e.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
        }
    }

    private String askForPasswordPurpose() {
        CustomInputDialog dialog = new CustomInputDialog(frame, "请输入密码的用途（必填）：");
        String purpose = dialog.getUserInput();
        return purpose != null ? purpose : "";
    }

    private String formatPasswordWithPurpose(String prefix, String password) {
        return "《" + prefix + "》：" + password;
    }


    private void hideFolder(String path) {
        if (System.getProperty("os.name").contains("Windows")) {
            try {
                ProcessBuilder pb = new ProcessBuilder("attrib", "+H", path);
                Process p = pb.start();
                p.waitFor();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(frame, "隐藏文件夹失败：" + e.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            System.out.println("非Windows系统不支");
        }
    }


    private void initialize() {
        frame = new JFrame();
        frame.setTitle("密码生成1.1|Code by abdesunny");
        frame.setBounds(100, 100, 365, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(new GridBagLayout());
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int x = (screenSize.width - frame.getWidth()) / 2;
        int y = (screenSize.height - frame.getHeight()) / 2;
        frame.setLocation(x, y);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0.5;

        JLabel lengthLabel = new JLabel("密码长度(自定义):");
        frame.getContentPane().add(lengthLabel, gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        lengthField = new JTextField(5);
        frame.getContentPane().add(lengthField, gbc);
        lengthField.setColumns(10);

        gbc.gridy = 1;
        gbc.gridx = 0;
        gbc.gridwidth = 1;
        JCheckBox lowercaseBox = new JCheckBox("包含小写字母");
        lowercaseBox.setSelected(true);
        frame.getContentPane().add(lowercaseBox, gbc);

        gbc.gridx = 1;
        JCheckBox uppercaseBox = new JCheckBox("包含大写字母");
        uppercaseBox.setSelected(true);
        frame.getContentPane().add(uppercaseBox, gbc);

        gbc.gridx = 2;
        JCheckBox numbersBox = new JCheckBox("包含数字");
        numbersBox.setSelected(true);
        frame.getContentPane().add(numbersBox, gbc);

        gbc.gridy = 2;
        gbc.gridx = 0;
        gbc.gridwidth = 3;
        JCheckBox specialCharsBox = new JCheckBox("包含特殊字符");
        frame.getContentPane().add(specialCharsBox, gbc);

        gbc.gridy = 3;
        gbc.gridx = 0;
        gbc.gridwidth = 1;
        JButton generateButton = new JButton("生成密码");
        generateButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    int length = Integer.parseInt(lengthField.getText());
                    if (!lowercaseBox.isSelected() && !uppercaseBox.isSelected() && !numbersBox.isSelected() && !specialCharsBox.isSelected()) {
                        lowercaseBox.setSelected(true);
                        uppercaseBox.setSelected(true);
                        numbersBox.setSelected(true);
                    }

                    String password = generator.generateCustomPassword(length,
                            lowercaseBox.isSelected(),
                            uppercaseBox.isSelected(),
                            numbersBox.isSelected(),
                            specialCharsBox.isSelected());
                    String purpose = askForPasswordPurpose();

                    String formattedPurpose = purpose.isEmpty()
                            ? LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))
                            : purpose;
                    String formattedPassword = formatPasswordWithPurpose(formattedPurpose, password);

                    resultLabel.setText("生成的密码:  " + password);
                    AutoCopy.copyTextToClipboard(password);
                    savePasswordToFile(formattedPassword);
                    JOptionPane.showMessageDialog(frame, "生成成功，密码已复制并保存", "成功", JOptionPane.INFORMATION_MESSAGE);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "输入有效的数字长度", "错误", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        frame.getContentPane().add(generateButton, gbc);

        gbc.gridy = 4;
        gbc.gridx = 0;
        gbc.gridwidth = 3;
        resultLabel = new JLabel("密码生成器v1.1");
        frame.getContentPane().add(resultLabel, gbc);
        frame.setVisible(true);
        gbc.gridy = 3;
        gbc.gridx = 1;
        gbc.gridwidth = 1;
        JButton viewPasswordsButton = new JButton("密码查看");
        viewPasswordsButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new PasswordViewer();
            }
        });
        frame.getContentPane().add(viewPasswordsButton, gbc);
    }

}
